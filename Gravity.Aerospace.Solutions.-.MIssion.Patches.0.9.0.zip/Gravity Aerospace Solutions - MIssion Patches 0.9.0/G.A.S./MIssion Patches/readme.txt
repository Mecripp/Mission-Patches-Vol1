Mission Patches by Lextacy

Installation:

Unzip the contents of the zip file directly to the KSP GameData folder, so the GAS folder ends up in the GameData directory. 

License: CC BY-NC-SA 3.0
