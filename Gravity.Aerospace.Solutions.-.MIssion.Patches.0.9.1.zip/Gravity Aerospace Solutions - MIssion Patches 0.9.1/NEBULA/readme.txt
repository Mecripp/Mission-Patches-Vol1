Mission Patches by Lextacy

version 0.9.1

changelog:

3/1/15 
-Fixed model/texture paths to correct name  

2/29/15
-Initial release



Installation:

Unzip the contents of the zip file directly to the KSP GameData folder, so the NEBULA folder ends up in the GameData directory. 


License: CC BY-NC-SA 3.0
